// Array para armazenar agendamentos
const bookings = [];

// Função para verificar disponibilidade
function isAvailable(date, time) {
    return !bookings.some(booking => booking.date === date && booking.time === time);
}

// Evento de submissão do formulário de login
document.getElementById('login-form').addEventListener('submit', function(event) {
    event.preventDefault();
    
    const email = document.getElementById('email').value.trim();
    
    // Liberar o formulário de agendamento independentemente dos dados inseridos
    document.getElementById('booking-form').style.display = 'block';
    document.getElementById('booking-title').style.display = 'block';
    document.getElementById('login-form').style.display = 'none';
    
    // Mostrar saudação com o email do usuário
    const userGreeting = document.getElementById('user-greeting');
    userGreeting.innerText = `Bem-vindo, ${email}!`;
    userGreeting.style.display = 'block';
});

// Evento de submissão do formulário de agendamento
document.getElementById('booking-form').addEventListener('submit', function(event) {
    event.preventDefault();
    
    const date = document.getElementById('date').value;
    const time = document.getElementById('time').value;
    
    if (!date || !time) {
        document.getElementById('confirmation').innerText = 'Por favor, preencha todos os campos.';
        document.getElementById('confirmation').style.color = 'red';
        return;
    }
    
    if (isAvailable(date, time)) {
        // Adiciona o novo agendamento ao array
        bookings.push({ date, time });
        
        const confirmationMessage = `Seu agendamento para ${date} às ${time} foi confirmado.`;
        document.getElementById('confirmation').innerText = confirmationMessage;
        document.getElementById('confirmation').style.color = 'green'; // Mensagem de confirmação em verde
        
        // Exibir o botão para voltar à página inicial
        document.getElementById('home-button-container').style.display = 'block';
        
        // Limpa os campos do formulário
        document.getElementById('booking-form').reset();
    } else {
        const errorMessage = `Desculpe, o horário ${time} do dia ${date} já está ocupado. Por favor, escolha outro horário.`;
        document.getElementById('confirmation').innerText = errorMessage;
        document.getElementById('confirmation').style.color = 'red'; // Mensagem de erro em vermelho
    }
});

// Adiciona evento para atualizar o título do campo com a data por extenso
document.getElementById("date").addEventListener("input", function() {
    let data = new Date(this.value);
    if (!isNaN(data)) {
        let options = { year: 'numeric', month: 'long', day: 'numeric' };
        this.setAttribute("title", data.toLocaleDateString('pt-BR', options));
    }
});
