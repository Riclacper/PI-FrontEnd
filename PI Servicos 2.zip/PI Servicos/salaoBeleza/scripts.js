// Carregar o CSS do agendamento quando o conteúdo for carregado
function loadAgendamentoStyles() {
    var link = document.createElement('link');
    link.rel = 'stylesheet';
    link.href = 'agendamento/styles.css';  // Verifique o caminho correto do CSS
    document.head.appendChild(link);
}

// Função para carregar a página de agendamento
function loadAgendamentoPage() {
    fetch('agendamento/index.html')
        .then(response => {
            if (!response.ok) {
                throw new Error('Erro ao carregar a página de agendamento.');
            }
            return response.text();
        })
        .then(data => {
            document.getElementById('agendamento-content').innerHTML = data;
            loadAgendamentoStyles();  // Carrega o CSS após o conteúdo
            // Adiciona o evento de clique ao botão Agendar
            document.getElementById('agendar-button').addEventListener('click', function() {
                // Mostra a notificação
                const confirmation = document.getElementById('confirmation');
                confirmation.style.display = 'block';

                // Esconde a notificação após 3 segundos
                setTimeout(() => {
                    confirmation.style.display = 'none';
                }, 3000);
            });
        })
        .catch(error => console.error('Erro ao carregar a página de agendamento:', error));
}

// Função para alternar as guias
document.querySelectorAll('.tab-link').forEach(tab => {
    tab.addEventListener('click', function(event) {
        event.preventDefault();

        // Esconder todas as seções
        document.querySelectorAll('.tab-content').forEach(content => content.classList.remove('active'));

        // Mostrar a seção correspondente
        const tabId = this.getAttribute('data-tab');
        document.getElementById(tabId).classList.add('active');

        // Se a guia selecionada for 'agendamento', carregar a página de agendamento
        if (tabId === 'agendamento') {
            loadAgendamentoPage();
        }
    });
});

// Inicializa a primeira aba (opcional)
document.querySelector('.tab-link').click();  // Você pode substituir por uma aba específica se necessário

// Script para alternar o menu em dispositivos móveis
document.querySelector('.menu-toggle').addEventListener('click', function() {
    document.querySelector('.bar-nav').classList.toggle('active');
});
