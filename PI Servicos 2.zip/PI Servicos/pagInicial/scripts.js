// scripts.js
document.addEventListener('DOMContentLoaded', function() {
    console.log('Página carregada');
});

const menuToggle = document.querySelector('.menu-toggle');
const nav = document.querySelector('nav');

menuToggle.addEventListener('click', (event) => {
    nav.classList.toggle('active'); // Alterna a classe 'active' no nav
    event.stopPropagation(); // Impede que o clique no botão feche o menu imediatamente
});

// Fecha o menu ao clicar fora dele
document.addEventListener('click', (event) => {
    if (!nav.contains(event.target) && !menuToggle.contains(event.target)) {
        nav.classList.remove('active'); // Remove a classe 'active'
    }
});