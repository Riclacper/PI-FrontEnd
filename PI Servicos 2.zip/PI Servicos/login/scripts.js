document.getElementById('loginForm').addEventListener('submit', function(event) {
    event.preventDefault();

    // Aqui você pode adicionar sua lógica de validação
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;

    // Simulando um login bem-sucedido
    if (username === "admin" && password === "12345") { // Exemplo: usuário admin e senha 12345
        Swal.fire({
            title: 'Login bem-sucedido!',
            text: 'Bem-vindo ao sistema!',
            icon: 'success',
            confirmButtonText: 'OK'
        }).then(() => {
            window.location.href = 'http://127.0.0.1:5500/pagInicial/index.html'; // Redireciona para a página inicial
        });
    } else {
        Swal.fire({
            title: 'Erro!',
            text: 'Usuário ou senha inválidos!',
            icon: 'error',
            confirmButtonText: 'Tentar novamente'
        });
    }
});
