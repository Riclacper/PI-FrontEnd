document.addEventListener('DOMContentLoaded', function() {
    function applyMask(input, mask) {
        input.addEventListener('input', function() {
            let value = input.value.replace(/\D/g, '');
            let newValue = '';
            let maskIndex = 0;
            for (let i = 0; i < value.length; i++) {
                if (maskIndex >= mask.length) break;
                if (mask[maskIndex] === '9') {
                    newValue += value[i];
                    maskIndex++;
                } else {
                    newValue += mask[maskIndex];
                    maskIndex++;
                    i--;
                }
            }
            input.value = newValue;
        });
    }

    function allowOnlyLetters(input) {
        input.addEventListener('input', function() {
            input.value = input.value.replace(/[^a-zA-Z\s]/g, '');
        });
    }

    const nomeInput = document.getElementById('nome');
    const telefoneInput = document.getElementById('telefone');
    const cpfInput = document.getElementById('cpf');
    const dataNascimentoInput = document.getElementById('dataNascimento');
    const senhaInput = document.getElementById('senha');
    const repetirSenhaInput = document.getElementById('repetirSenha');
    const cadastroForm = document.getElementById('cadastroForm');
    const popup = document.getElementById('popup');
    const closeBtn = document.querySelector('.close');

    allowOnlyLetters(nomeInput);
    applyMask(telefoneInput, '(99) 99999-9999');
    applyMask(cpfInput, '999.999.999-99');
    applyMask(dataNascimentoInput, '99/99/9999');

    cadastroForm.addEventListener('submit', function(event) {
        event.preventDefault();
        if (senhaInput.value !== repetirSenhaInput.value) {
            alert('As senhas não coincidem. Por favor, verifique.');
            return;
        }
        popup.style.display = 'block';
    });

    closeBtn.addEventListener('click', function() {
        popup.style.display = 'none';
    });

    window.addEventListener('click', function(event) {
        if (event.target === popup) {
            popup.style.display = 'none';
        }
    });
});
// scripts.js

document.getElementById('cadastroForm').addEventListener('submit', function(event) {
    event.preventDefault(); // Impede o envio do formulário

    // Exibe o popup
    document.getElementById('popup').style.display = 'flex';

    // Fecha o popup ao clicar no "x"
    document.querySelector('.popup .close').addEventListener('click', function() {
        document.getElementById('popup').style.display = 'none';
    });
});
